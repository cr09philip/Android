package cn.kc.demo.audio;

import android.content.Context;

public class AudioRecoder {

	public AudioRecoder(Context context) {
		// TODO Auto-generated constructor stub
	}

}
