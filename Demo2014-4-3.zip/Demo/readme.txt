========================================================
2013-11-20 17:33:14
philip
update:
1.modify bug---when item onClick 
todo list
1.while one song playing ,switch to others maybe cant play
2.play when download
3.resend file
========================================================
========================================================
2013-11-20 9:20:00
philip
update:
1.modify download refresh UI 

remain bugs
1. item onClick 
todo list
1.while one song playing ,switch to others maybe cant play
2.play when download
3.resend file
>>>>>>> d950eb6b2c5acc16e377d7dff71acc5c8ab97a66
========================================================
========================================================
<<<<<<< HEAD
2013-11-17 23:36:31
philip
update:
1.modify SOCKET PART
todo list
1.PLAY WHEN DOWNLOAD
2.DOWNLOAD REFRESH UI
3.PLAY A SONG ,SWITCH TO OTHER ,BUGS 
=======
2013-11-17 23:27:58
philip
update:
1.modify socket part almost finish

todo list
1.download refresh UI
2.while one song playing ,switch to others maybe cant play
3.play when download
4.resend file
>>>>>>> d950eb6b2c5acc16e377d7dff71acc5c8ab97a66
========================================================
========================================================
2013-11-16 14:54:08
philip
update:
1.modify BaseAudioPlayer,change time calc mothod
    from Timer to mAudioTrack.getPlaybackHeadPosition()/mFrequency

todo list
1.modify net module, move handle into here,and supply 
	some callback to call for activity
2.code and test stream player
3.set some test voice into phone
========================================================
========================================================
2013-11-16 14:54:08
philip
update:
1.modify FilePlayer finish

todo list
1.modify net module, move handle into here,and supply 
	some callback to call for activity
2.code and test stream player
3.set some test voice into phone
========================================================