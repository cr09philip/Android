package cn.kc.demo.utils;

public class Utils {
}
