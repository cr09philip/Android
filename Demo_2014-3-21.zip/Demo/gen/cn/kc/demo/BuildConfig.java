/** Automatically generated file. DO NOT MODIFY */
package cn.kc.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}